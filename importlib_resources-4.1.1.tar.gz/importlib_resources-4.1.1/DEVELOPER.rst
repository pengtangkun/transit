Releases
========

To cut a release:

1. Ensure the changelog is up-to-date with the commits since the last release.
2. Bump the version in version.txt.
3. Commit those changes. Tag the commit with the version.
4. Push the changes.
