<!--
 * @Descripttion: kafka指标采集脚本说明
 * @Author: Lrene Le
 * @Date: 2021-09-28 10:27:47
 * @LastEditTime: 2021-09-28 19:55:59
-->
## Kafka

一 采集指标

| 指标说明 | 指标参数     |
|--------| -------------|
| 1 kafka集群中broker的数量 | kafka_brokers |
| 2 指定topic下的partion数   |  kafka_topic_partitions |
| 3 占用cpu时间（秒）    | process_cpu_seconds_total  |
| 4 允许打开的最大文件数   | process_max_fds  |
| 5 打开的文件数   | process_open_fds |
| 6 占用内存字节数 | process_resident_memory_bytes |
| 7 启动时间戳 | process_start_time_seconds  |

二 使用方法

安装第三方模块pykafka：
    pip3 install pykafka -i http://pypi.douban.com/simple/ --trusted-host pypi.douban.com

python kafkaIndicators.py --ip ip地址 --port 端口号 --topic 主题

示例:
    python3 kafka2.py --ip 10.0.8.105 --port 18108 --topic test

数据样例：

    {
        "kafka_brokers": 2,
        "process_max_fds": "1043576",
        "process_open_fds": "0",
        "process_start_time_seconds": "1632711461",
        "process_cpu_seconds_total": "117901",
        "process_resident_memory_bytes": "1305984",
        "kafka_topic_partitions{topic=test}": 8
    }