'''
Descripttion: 
Author: Lrene Le
Date: 2021-09-27 10:21:09
'''

import json

from pykafka import Cluster, handlers
import subprocess
import argparse
import sys


class KafkaIndiactors:
    def __init__(self, ip, port, topic):
        self.ip = ip
        self.port = port
        self.topic = topic
        self.kafkaInfos = dict()

    def cmd(self, command):
        '''
        执行系统命令
        :param command: 命令
        :return: 输出结果，报错，执行状态
        '''
        p = subprocess.Popen(command, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, shell=True)
        stdout, stderr = p.communicate()
        try:
            return stdout.decode("utf8"), stderr.decode("utf8"), p.returncode
        except:
            return stdout.decode("gbk"), stderr.decode("gbk"), p.returncode

    def connectKafka(self):
        '''
        msg: 连接kafka
        param {*}
        return {*}
        '''
        try:
            self.handler = handlers.ThreadingHandler()
            self.cluster = Cluster(hosts=r'{0}:{1}'.format(
                self.ip, self.port), handler=self.handler)
            return
        except Exception as err:
            print("连接Kafka失败：", err)
            exit(1)

    def brokersNum(self):
        '''
        msg: kafka集群中broker的数量
        param {*}
        return {*}
        '''
        try:
            broNums = len(self.cluster.brokers.items())
            self.kafkaInfos["kafka_brokers"] = broNums
        except Exception as err:
            self.kafkaInfos["kafka_brokers"] = 0
        return

    def mainKafkaInfo(self, topic):
        '''
        msg: 指定topic下的partion数
        param {*}
        return {*}
        '''
        key = r'kafka_topic_partitions{topic=%s}' %topic
        try:
            descrip = self.cluster.topics[topic]
            partitions = len(descrip.partitions.items())
            self.kafkaInfos[key] = partitions
        except Exception as err:
            self.kafkaInfos[key] = 0
        return

    def kafkaFiles(self):
        '''
        msg: 查询用户级别限制的最大文件数
             查询已经打开的文件数
             启动时间戳
             占用cpu时间（秒）
             占用内存字节数
        param {*}
        return {*}
        '''
        # 获取kafka pid
        command = r"ps ax | grep -i 'kafka\.Kafka' | grep java | grep -v grep | awk '{print $1}'"
        pid, _, _ = self.cmd(command)
        # 查询用户级别限制的最大文件数
        command = r'ulimit -n'
        process_max_fds, _, _ = self.cmd(command)
        self.kafkaInfos["process_max_fds"] = process_max_fds.strip()
        # 查询已经打开的文件数
        command = r'll /proc/{}/fd |wc -l'.format(pid.strip())
        process_open_fds, _, _ = self.cmd(command)
        self.kafkaInfos["process_open_fds"] = process_open_fds.strip()
        # 启动时间戳
        command = r'ps -eo pid,lstart|grep {}'.format(pid)
        stdout, err, code = self.cmd(command)
        res = [em.strip() for em in stdout.split(" ") if em]
        res.pop(0)
        date = " ".join(res).strip()
        command = r'date -d "{}" +%s'.format(date)
        stdout, err, code = self.cmd(command)
        self.kafkaInfos["process_start_time_seconds"] = stdout.strip()
        # 占用cpu时间（秒）
        command = r'ps -eo pid,etimes|grep {}'.format(pid)
        stdout, err, code = self.cmd(command)
        res = [em.strip() for em in stdout.split(" ") if em]
        self.kafkaInfos["process_cpu_seconds_total"] = res[1].strip()
        # 占用内存字节数
        command = r'ps -eo pid,rss|grep {}'.format(pid)
        stdout, err, code = self.cmd(command)
        res = [em.strip() for em in stdout.split(" ") if em]
        self.kafkaInfos["process_resident_memory_bytes"] = res[1].strip()
        return

    def main(self):
        '''
        msg: 调用
        param {*}
        return {*}
        '''
        self.connectKafka()
        self.brokersNum()
        self.kafkaFiles()
        self.mainKafkaInfo(self.topic)
        return json.dumps(self.kafkaInfos)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='登录kafka，采集kafka相关信息')
    parser.add_argument('--ip', dest='ip', type=str, help='kafka ip')
    parser.add_argument('--port', dest='port', type=str, help='kafka port')
    parser.add_argument('--topic', dest='topic', type=str, help='kafka topic')
    args = parser.parse_args(sys.argv[1:])
    result = KafkaIndiactors(
        args.ip, args.port, args.topic).main()
    print(result)
