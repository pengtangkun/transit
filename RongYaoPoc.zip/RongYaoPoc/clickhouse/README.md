## clickhouse

一 采集指标

| 指标说明 | 指标参数     |
|--------| -------------|
| 1 处理的总查询数（包括insert） | Query |
| 2 由于写入负载过高，延迟写入的Block数量 | DelayedInserts |
| 3 Merge的数据行数 | MergedRows |
| 4 后台正在执行任务的线程数 | BackgroundPoolTask |
| 5 执行Merge的总次数 | Merge |
| 6 执行ALTER UPDATE/DELETE的次数 | PartMutation |
| 7 SELECT查询的次数 | SelectQuery |
| 8 分配给server的内存总数 | MemoryTracking |
| 9 当前只读的副本数 | ReadonlyReplica |

二 使用方法
安装第三方模块clickhouse_driver：
pip3 install clickhouse_driver -i http://pypi.douban.com/simple/ --trusted-host pypi.douban.com

有密码的Clickhouse 
python clickhouse.py --ip ip地址 --port 端口号 --user 用户名 --passwd 密码

没有密码的Clickhouse
python clickhouse.py --ip ip地址 --port 端口号 

示例

python clickhouse.py --ip 10.0.9.150 --port 9000 --user default --passwd default
