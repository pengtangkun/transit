#!/usr/bin/env python3
# encoding: utf-8
# Author: burce.wang
# Create Date: 2021/9/27 14:00
# Description: 该脚本用于clickhouse(20.1.6.30)指标深度采集
import getopt
import json
import sys

from clickhouse_driver import Client


class ClickhouseCollect(object):

    def __init__(self):
        """
        初始化clickhouse连接参数
        :param host clickhouse主机地址
        :param port clickhouse连接端口
        :param user clickhouse连接用户
        :param passwd clickhouse用户密码
        """
        self.host = "127.0.0.1"
        self.port = 9000
        self.user = "default"
        self.passwd = ""

    def usage(self):
        print(
            """
            参数说明:
            --ip      : 请求连接的clickhouse的地址
            --port    : 请求连接的clickhouse的端口
            --user    : clickhouse用户名
            --passwd  : clickhouse密码
            -h       : 帮助信息
            """.format(sys.argv[0]))

    def connect_clickhouse(self):
        try:
            opts, args = getopt.getopt(sys.argv[1:], "hi:o:", ["ip=", "port=", "user=", "passwd="])
            for op, value in opts:
                # if op not in ('-i',"--ip", "--port", "--user", "--passwd"):
                #     print("没有该命令：%s,请使用-h参数获取帮助" %value)
                if op == '--ip':
                    self.host = value
                elif op == "--port":
                    self.port = value
                elif op == "--user":
                    self.user = value
                elif op == "--passwd":
                    self.passwd = value
                elif op == "-h":
                    self.usage()
                    sys.exit()
            if self.passwd == None:
                self.client = Client(host=self.host, port=self.port, user=self.user)
            else:
                self.client = Client(host=self.host, port=self.port, user=self.user, password=self.passwd)
        except AttributeError as e:
            print(e)

    def sql_execute(self, sql):
        """
        clickhouse执行命令
        :return:
        """
        sql_valve = self.client.execute(sql)
        return sql_valve

    def get_query_total(self):
        """
        处理的总查询数（包括insert）
        :return:
        """
        sql = "select value from system.events where event = 'Query';"
        return self.sql_execute(sql)

    def get_delayed_insert(self):
        """
        由于写入负载过高，延迟写入的Block数量
        :return:
        """
        sql = "select value from system.metrics where metric = 'DelayedInserts';"
        return self.sql_execute(sql)

    def get_merged_rows_total(self):
        """
        Merge的数据行数
        :return:
        """
        sql = "select value from system.events where event = 'MergedRows';"
        return self.sql_execute(sql)

    def get_background_rows_total(self):
        """
        后台正在执行任务的线程数
        :return:
        """
        sql = "select value from system.metrics where metric = 'BackgroundPoolTask';"
        return self.sql_execute(sql)

    def get_merge_total(self):
        """
        执行Merge的总次数
        :return:
        """
        sql = "select value from system.metrics where metric = 'Merge';"
        return self.sql_execute(sql)

    def get_clickhouse_part_mutation(self):
        """
        执行ALTER UPDATE/DELETE的次数
        :return:
        """
        sql = "select value from system.metrics where metric = 'PartMutation';"
        return self.sql_execute(sql)

    def get_clickhouse_select_query_total(self):
        """
        SELECT查询的次数
        :return:
        """
        sql = "select value from system.events where event = 'SelectQuery';"
        return self.sql_execute(sql)

    def get_clickhouse_memory_tracking(self):
        """
        分配给server的内存总数
        :return:
        """
        sql = "select value from system.metrics where metric = 'MemoryTracking';"
        return self.sql_execute(sql)

    def get_clickhouse_readonly_replica(self):
        """
        当前只读的副本数
        :return:
        """
        sql = "select value from system.metrics where metric = 'ReadonlyReplica';"
        return self.sql_execute(sql)

    def main(self):
        self.connect_clickhouse()
        query_value = self.get_query_total()
        delayedinserts_value = self.get_delayed_insert()
        mergedrows_value = self.get_merged_rows_total()
        backgroundpooltask_value = self.get_background_rows_total()
        merge_value = self.get_merge_total()
        partmutation_value = self.get_clickhouse_part_mutation()
        selectquery_value = self.get_clickhouse_select_query_total()
        memorytracking_value = self.get_clickhouse_memory_tracking()
        readonlyreplica_value = self.get_clickhouse_readonly_replica()
        clickhouse_msg_dict = {
            "Query": query_value[0][0],
            "DelayedInserts": delayedinserts_value[0][0],
            "MergedRows": mergedrows_value[0][0],
            "BackgroundPoolTask": backgroundpooltask_value[0][0],
            "Merge": merge_value[0][0],
            "PartMutation": partmutation_value[0][0],
            "SelectQuery": selectquery_value[0][0],
            "MemoryTracking": memorytracking_value[0][0],
            "ReadonlyReplica": readonlyreplica_value[0][0]
        }
        clickhouse_msg_json = json.dumps(clickhouse_msg_dict)
        print(clickhouse_msg_json)
        return clickhouse_msg_json

if __name__ == '__main__':
    ClickhouseCollect().main()

