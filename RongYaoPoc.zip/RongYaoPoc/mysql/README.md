## Mysql

一 采集指标

| 指标说明 | 指标参数     |
|--------| -------------|
| 1 版本信息 | mysql_version_info |
| 2 允许打开的文件描述符最大值   |  process_max_fds |
| 3 启动时间戳（秒）    | process_start_time_seconds  |
| 4 意外中断的客户端数   | mysql_global_status_aborted_clients  |
| 5 意外中断的连接数   | mysql_global_status_aborted_connects |
| 6 创建临时文件的次数 | mysql_global_status_created_tmp_files |
| 7 创建临时表的次数 | mysql_global_status_created_tmp_tables |
| 8 innodb行级锁时间 | mysql_global_status_innodb_row_lock_time |
| 9 innodb行级锁平均时间 | mysql_global_status_innodb_row_lock_time_avg |
| 10 innodb行级锁最大时间 | mysql_global_status_innodb_row_lock_time_max |
| 11 当前打开的文件数 | mysql_global_status_open_files |
| 12 当前打开的表总数 | mysql_global_status_open_tables |
| 13 接收查询的次数（包括存储过程） | mysql_global_status_queries |
| 14 接收查询的次数（不包括存储过程） | mysql_global_status_questions |
| 15 慢查询数  | mysql_global_status_slow_queries |
| 16 服务运行时间（秒） | mysql_global_status_uptime |
| 17 binlog日志缓存大小 | mysql_global_variables_binlog_cache_size |
| 18 连接超时时间 | mysql_global_variables_connect_timeout |
| 19 mysql压缩级别 | mysql_global_variables_innodb_compression_level |
| 20 innodb引擎锁等待超时时间 | mysql_global_variables_innodb_lock_wait_timeout |
| 21 binlog日志最大允许值 | mysql_global_variables_max_binlog_size |
| 22 允许的最大连接数 | mysql_global_variables_max_connections |
| 23 打开文件限制数 | mysql_global_variables_open_files_limit |
| 24 服务端口 | mysql_global_variables_port |
| 25 只读,可读写时为0，只读为1 | mysql_global_variables_read_only |

二 使用方法

python mysql.py --ip ip地址 --port 端口号 --user 用户名 --passwd 密码

示例

python mysql.py --ip 10.0.9.150 --port 18103 --user Rootmaster --passwd Rootmaster@777

三 使用的三方库 

pymysql



