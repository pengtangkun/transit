#!/usr/bin/env python3
# -*- coding:utf8 -*-
# Author: light.wang <youremail@example.com>
# Create Date: 2021-09-28 10:21:17
# Last Modified: 2021-09-28 17:52:17
# Description: 该适配操作系统：centos6、7
import json
import pymysql
import argparse
import subprocess


class MysqlCollectInfo(object):

    def __init__(self):
        # 检测mysql运行状态,运行时值为1
        mysql_up_status = self.shell_value('ps -ef|grep -o mysqld|wc -l').strip()
        self.mysql_up = 1 if int(mysql_up_status) > 2 else ''

    # shell标准输出
    @staticmethod
    def shell_value(cmd):
        shell = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        cmd_stdout = bytes.decode(shell.stdout)
        return cmd_stdout

    # 参数定义
    @staticmethod
    def arguments():
        parser = argparse.ArgumentParser()
        parser.add_argument("-ip", "--ip_address", help="IP ADDRESS")
        parser.add_argument("-port", "--port", help="PORT", default=3306)
        parser.add_argument("-user", "--user", help="USER", default='root')
        parser.add_argument("-passwd", "--passwd", help="PASSWD", default='root')
        args = parser.parse_args()
        return args

    # 连接数据库
    def mysql_value(self,sql):
        args = self.arguments()
        conn = pymysql.connect(host=args.ip_address, user=args.user, password=args.passwd,port=int(args.port))
        cursor = conn.cursor()
        cursor.execute(sql)
        cursor.close()
        conn.close()
        return cursor

    # 版本信息
    def mysql_version_info(self):
        sql = 'select version() from dual;'
        mysql_version_info_value = self.mysql_value(sql).fetchone()[0] if self.mysql_up == 1 else ''
        return mysql_version_info_value

    # 允许打开的文件描述符最大值
    def process_max_fds(self):
        sql = 'show global variables like "%open_files_limit%";'
        process_max_fds_value = int(self.mysql_value(sql).fetchone()[1]) if self.mysql_up == 1 else ''
        return process_max_fds_value

    # 启动时间戳（秒）
    def process_start_time_seconds(self):
        sql = "show global status like 'uptime';"
        process_start_time_seconds_value = self.mysql_value(sql).fetchone()[1] if self.mysql_up == 1 else ''
        return process_start_time_seconds_value

    # 意外中断的客户端数
    def mysql_global_status_aborted_clients(self):
        sql = "show status like 'Aborted_clients';"
        mysql_global_status_aborted_clients_value = self.mysql_value(sql).fetchone()[1] if self.mysql_up == 1 else ''
        return mysql_global_status_aborted_clients_value

    # 意外中断的连接数
    def mysql_global_status_aborted_connects(self):
        sql = "show status like '%Aborted_connects%';"
        mysql_global_status_aborted_connects_value = self.mysql_value(sql).fetchone()[1] if self.mysql_up == 1 else ''
        return mysql_global_status_aborted_connects_value

    # 创建临时文件的次数
    def mysql_global_status_created_tmp_files(self):
        sql = "show global status like 'created_tmp_files%';"
        mysql_global_status_created_tmp_files_value = self.mysql_value(sql).fetchone()[1] if self.mysql_up == 1 else ''
        return mysql_global_status_created_tmp_files_value

    # 创建临时表的次数
    def mysql_global_status_created_tmp_tables(self):
        sql = "show global status like 'created_tmp_tables%';"
        mysql_global_status_created_tmp_tables_value = self.mysql_value(sql).fetchone()[1] if self.mysql_up == 1 else ''
        return mysql_global_status_created_tmp_tables_value

    # innodb行级锁时间
    def mysql_global_status_innodb_row_lock_time(self):
        sql = "show status like 'InnoDB_row_lock_time';"
        mysql_global_status_innodb_row_lock_time_value = self.mysql_value(sql).fetchone()[1] if self.mysql_up == 1 else ''
        return mysql_global_status_innodb_row_lock_time_value

    # innodb行级锁平均时间
    def mysql_global_status_innodb_row_lock_time_avg(self):
        sql = "show status like 'InnoDB_row_lock_time_avg';"
        mysql_global_status_innodb_row_lock_time_avg_value = self.mysql_value(sql).fetchone()[1] if self.mysql_up == 1 else ''
        return mysql_global_status_innodb_row_lock_time_avg_value

    # innodb行级锁最大时间
    def mysql_global_status_innodb_row_lock_time_max(self):
        sql = "show status like 'InnoDB_row_lock_time_max';"
        mysql_global_status_innodb_row_lock_time_max_value = self.mysql_value(sql).fetchone()[1] if self.mysql_up == 1 else ''
        return mysql_global_status_innodb_row_lock_time_max_value

    # 当前打开的文件数
    def mysql_global_status_open_files(self):
        sql = "show global status like 'open_files%';"
        mysql_global_status_open_files_value = self.mysql_value(sql).fetchone()[1] if self.mysql_up == 1 else ''
        return mysql_global_status_open_files_value

    # 当前打开的表总数
    def mysql_global_status_open_tables(self):
        sql = "show global status like 'open_tables%';"
        mysql_global_status_open_tables_value = self.mysql_value(sql).fetchone()[1] if self.mysql_up == 1 else ''
        return mysql_global_status_open_tables_value

    # 接收查询的次数（包括存储过程）
    def mysql_global_status_queries(self):
        sql = "show global status like 'Queries%';"
        mysql_global_status_queries_value = self.mysql_value(sql).fetchone()[1] if self.mysql_up == 1 else ''
        return mysql_global_status_queries_value

    # 接收查询的次数（不包括存储过程）
    def mysql_global_status_questions(self):
        sql = "show global status like 'questions%';"
        mysql_global_status_questions_value = self.mysql_value(sql).fetchone()[1] if self.mysql_up == 1 else ''
        return mysql_global_status_questions_value

    # 慢查询数
    def mysql_global_status_slow_queries(self):
        sql = "show global status like '%slow_queries%';"
        mysql_global_status_slow_queries_value = self.mysql_value(sql).fetchone()[1] if self.mysql_up == 1 else ''
        return mysql_global_status_slow_queries_value

    # 服务运行时间（秒）
    def mysql_global_status_uptime(self):
        sql = "SHOW GLOBAL STATUS LIKE 'UPTIME';"
        mysql_global_status_uptime_value = self.mysql_value(sql).fetchone()[1] if self.mysql_up == 1 else ''
        return mysql_global_status_uptime_value

    # binlog日志缓存大小
    def mysql_global_variables_binlog_cache_size(self):
        sql = "show master logs;"
        log_size = [log[1] for log in self.mysql_value(sql).fetchall()]
        mysql_global_variables_binlog_cache_size_value = sum(log_size) if self.mysql_up == 1 else ''
        return mysql_global_variables_binlog_cache_size_value

    # 连接超时时间
    def mysql_global_variables_connect_timeout(self):
        sql = "show variables like 'connect_timeout';"
        mysql_global_variables_connect_timeout_value = self.mysql_value(sql).fetchone()[1] if self.mysql_up == 1 else ''
        return mysql_global_variables_connect_timeout_value

    # mysql压缩级别
    def mysql_global_variables_innodb_compression_level(self):
        sql = "show variables like 'innodb_compression_level';"
        mysql_global_variables_innodb_compression_level_value = self.mysql_value(sql).fetchone()[1] if self.mysql_up == 1 else ''
        return mysql_global_variables_innodb_compression_level_value

    # innodb引擎锁等待超时时间
    def mysql_global_variables_innodb_lock_wait_timeout(self):
        sql = "show variables like 'innodb_lock_wait_timeout'; "
        mysql_global_variables_innodb_lock_wait_timeout_value = self.mysql_value(sql).fetchone()[1] if self.mysql_up == 1 else ''
        return mysql_global_variables_innodb_lock_wait_timeout_value

    # binlog日志最大允许值
    def mysql_global_variables_max_binlog_size(self):
        sql = "show variables like 'max_binlog_size';"
        mysql_global_variables_max_binlog_size_value = self.mysql_value(sql).fetchone()[1] if self.mysql_up == 1 else ''
        return mysql_global_variables_max_binlog_size_value

    # 允许的最大连接数
    def mysql_global_variables_max_connections(self):
        sql = "show variables like 'max_connections';"
        mysql_global_variables_max_connections_value = self.mysql_value(sql).fetchone()[1] if self.mysql_up == 1 else ''
        return mysql_global_variables_max_connections_value

    # 打开文件限制数
    def mysql_global_variables_open_files_limit(self):
        sql = "show variables like 'open_files_limit';"
        mysql_global_variables_open_files_limit_value = self.mysql_value(sql).fetchone()[1] if self.mysql_up == 1 else ''
        return mysql_global_variables_open_files_limit_value

    # 服务端口
    def mysql_global_variables_port(self):
        sql = "show variables like 'port';"
        mysql_global_variables_port_value = self.mysql_value(sql).fetchone()[1] if self.mysql_up == 1 else ''
        return mysql_global_variables_port_value

    # 只读,可读写时为0，只读为1
    def mysql_global_variables_read_only(self):
        sql = "show variables like 'read_only';"
        if self.mysql_up == 1:
            mysql_global_variables_read_only_value = 0 if self.mysql_value(sql).fetchone()[1].lower() == 'off' else 1
        else:
            mysql_global_variables_read_only_value = ''
        return mysql_global_variables_read_only_value

    # 收集指标信息
    def run(self):
        collected_info = {
            'mysql_up': self.mysql_up,
            'process_max_fds': self.process_max_fds(),
            'mysql_version_info': self.mysql_version_info(),
            'mysql_global_status_uptime': self.mysql_global_status_uptime(),
            'process_start_time_seconds': self.process_start_time_seconds(),
            'mysql_global_status_queries': self.mysql_global_status_queries(),
            'mysql_global_variables_port': self.mysql_global_variables_port(),
            'mysql_global_status_questions': self.mysql_global_status_questions(),
            'mysql_global_status_open_files': self.mysql_global_status_open_files(),
            'mysql_global_status_open_tables': self.mysql_global_status_open_tables(),
            'mysql_global_variables_read_only': self.mysql_global_variables_read_only(),
            'mysql_global_status_slow_queries': self.mysql_global_status_slow_queries(),
            'mysql_global_status_aborted_clients': self.mysql_global_status_aborted_clients(),
            'mysql_global_status_aborted_connects': self.mysql_global_status_aborted_connects(),
            'mysql_global_status_created_tmp_files': self.mysql_global_status_created_tmp_files(),
            'mysql_global_variables_connect_timeout': self.mysql_global_variables_connect_timeout(),
            'mysql_global_variables_max_binlog_size': self.mysql_global_variables_max_binlog_size(),
            'mysql_global_variables_max_connections': self.mysql_global_variables_max_connections(),
            'mysql_global_status_created_tmp_tables': self.mysql_global_status_created_tmp_tables(),
            'mysql_global_variables_open_files_limit': self.mysql_global_variables_open_files_limit(),
            'mysql_global_status_innodb_row_lock_time': self.mysql_global_status_innodb_row_lock_time(),
            'mysql_global_variables_binlog_cache_size': self.mysql_global_variables_binlog_cache_size(),
            'mysql_global_status_innodb_row_lock_time_avg': self.mysql_global_status_innodb_row_lock_time_avg(),
            'mysql_global_status_innodb_row_lock_time_max': self.mysql_global_status_innodb_row_lock_time_max(),
            'mysql_global_variables_innodb_lock_wait_timeout': self.mysql_global_variables_innodb_lock_wait_timeout(),
            'mysql_global_variables_innodb_compression_level': self.mysql_global_variables_innodb_compression_level(),
        }
        print(json.dumps(collected_info))
        return json.dumps(collected_info)


if __name__ == '__main__':
    collect_info = MysqlCollectInfo()
    collect_info.run()
    # 示例
    # python3 mysql.py --ip 10.0.9.150 --port 18103 --user Rootmaster --passwd Rootmaster@777
