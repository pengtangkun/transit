'''
Descripttion: 
Author: Lrene Le
Date: 2021-09-26 15:56:45
'''

import subprocess
from redis import Redis
import sys
import argparse
import json


class ConnectRedis(object):
    '''
    msg: 连接redis
    param {*}
    return {*}
    '''
    __flag = None

    def __new__(cls, *args, **kwargs):
        if not cls.__flag:
            cls.__flag = super().__new__(cls)
        return cls.__flag

    def __init__(self, ip, port, pwd):
        if 'cursor' not in self.__dict__:
            redis_host = ip
            redis_port = port
            redis_password = pwd
            redis_conn = Redis(
                host=redis_host, port=redis_port, password=redis_password)
            self.cursor = redis_conn

    def get_cursor(self):
        return self.cursor


class RedisIndicators:
    def __init__(self, ip, port, pwd):
        self.ip = ip
        self.port = port
        self.pwd = pwd
        self.redisInfo = dict()

    def cmd(self, command):
        '''
        执行系统命令
        :param command: 命令
        :return: 输出结果，报错，执行状态
        '''
        p = subprocess.Popen(command, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, shell=True)
        stdout, stderr = p.communicate()
        try:
            return stdout.decode("utf8"), stderr.decode("utf8"), p.returncode
        except:
            return stdout.decode("gbk"), stderr.decode("gbk"), p.returncode

    def connetctRedis(self):
        '''
        msg: 连接redis
        param {*}
        return {*}
        '''
        try:
            self.cursor = ConnectRedis(
                self.ip, self.port, self.pwd).get_cursor()
            self.redisInfo["redis_up"] = 1
            return
        except Exception as err:
            self.redisInfo["redis_up"] = 0
            print("连接redis失败：", err)
            exit(1)

    def redisGeneralInfo(self):
        '''
        msg: 允许redis做aof持久化 ......
        param {*}
        return {*}
        '''
        infoFragment = self.cursor.info()
        mainInfo = {"connected_clients":"redis_connected_clients", "total_system_memory":"redis_config_maxmemory", "process_id":"redis_process_id", "aof_enabled":"redis_aof_enabled", "total_connections_received":"redis_connections_received_total", "expired_keys":"redis_expired_keys_total", "cluster_enabled":"redis_cluster_enabled",

                    "connected_slaves":"redis_connected_slaves", "rejected_connections":"redis_rejected_connections_total", "uptime_in_seconds":"redis_uptime_in_seconds", "evicted_keys":"redis_evicted_keys_total", "used_memory":"redis_memory_used_bytes","used_memory_peak":"redis_memory_used_peak_bytes", "used_memory_rss":"redis_memory_used_rss_bytes", "blocked_clients":"redis_blocked_clients"}
        for el in mainInfo.keys():
            if not self.redisInfo.__contains__(el):
                self.redisInfo[mainInfo[el]] = infoFragment[el]
            else:
                self.redisInfo[el] = ""
        command = r'ps -eo pid,lstart|grep {}'.format(
            self.redisInfo["redis_process_id"])
        stdout, err, code = self.cmd(command)
        res = [em.strip() for em in stdout.split(" ") if em]
        res.pop(0)
        date = " ".join(res).strip()
        command = r'date -d "{}" +%s'.format(date)
        stdout, err, code = self.cmd(command)
        self.redisInfo["redis_start_time_seconds"] = stdout.strip()
        return

    def redis_db_keys(self):
        '''
        msg: db0中key数量 {db="db0"} 1
        param {*}
        return {*}
        '''
        try:
            db0Num = self.cursor.dbsize()
            self.redisInfo["redis_db_keys"] = db0Num
        except Exception as err:
            self.redisInfo["redis_db_keys"] = 0
        return

    def redis_config_maxclients(self):
        '''
        msg: 允许最大连接客户端数
        param {*}
        return {*}
        '''
        try:
            redis_config_maxclients = self.cursor.config_get("maxclients")
            self.redisInfo["redis_config_maxclients"] = int(redis_config_maxclients["maxclients"])
        except Exception as err:
            self.redisInfo["redis_config_maxclients"] = ""
        return      


    def redis_instance_info(self):
        '''
        msg: redis实例信息
        param {*}
        return {*}
        '''
        try:
            info = self.cursor.info()
            self.redisInfo["redis_instance_info"] = info
        except Exception as err:
            self.redisInfo["redis_instance_info"] = ""
        return

    def main(self):
        '''
        msg: 调用函数获取信息，以json格式输出
        param {*}
        return {*}
        '''
        self.connetctRedis()
        self.redisGeneralInfo()
        self.redis_db_keys()
        self.redis_config_maxclients()
        return json.dumps(self.redisInfo)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='登录redis，采集redis相关信息')
    parser.add_argument('--ip', dest='ip', type=str, help='redis ip')
    parser.add_argument('--port', dest='port', type=str,
                        help='redis port', default=6379)
    parser.add_argument('--passwd', dest='passwd',
                        type=str, help='redis password', default="")
    args = parser.parse_args(sys.argv[1:])
    result = RedisIndicators(args.ip, args.port, args.passwd).main()
    print(result)
