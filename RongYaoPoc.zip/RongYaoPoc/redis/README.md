<!--
 * @Descripttion: redis指标采集脚本说明
 * @Author: Lrene Le
 * @Date: 2021-09-28 10:27:47
 * @LastEditTime: 2021-09-29 10:28:54
-->
## Redis

一 采集指标

| 指标说明 | 指标参数     |
|--------| -------------|
| 1 允许redis做aof持久化 | redis_aof_enabled |
| 2 阻塞的客户端数   |  redis_blocked_clients |
| 3 是否允许创建集群    | redis_cluster_enabled  |
| 4 分配给redis的最大内存   | redis_config_maxmemory |
| 5 建立连接的客户端数 | redis_connected_clients |
| 6 从站数 | redis_connected_slaves |
| 7 接收到的连接总数 | redis_connections_received_total |
| 8 db0中key数量 | redis_db_keys |
| 9 回收的key总数 | redis_evicted_keys_total |
| 10 过期的key总数 | redis_expired_keys_total |
| 11 redis使用内存字节数 | redis_memory_used_bytes |
| 12 redis使用内存峰值  | redis_memory_used_peak_bytes |
| 13 redis数据占用内存字节数 | redis_memory_used_rss_bytes |
| 14 redis进程pid | redis_process_id |
| 15 redis拒绝连接总数 | redis_rejected_connections_total |
| 16 redis启动时间戳 | redis_start_time_seconds |
| 17 redis运行时间（秒） | redis_uptime_in_seconds |
| 18 redis状态值 | redis_up |

二 使用方法
安装第三方模块redis:
    pip3 install redis -i http://pypi.douban.com/simple/ --trusted-host pypi.douban.com

python3 redis_indicators.py --ip ip地址 --port 端口号 --passwd 密码

示例:
    python3 redis_indicators.py --ip 10.0.14.156 --port 2020 --passwd /opt/lrene/tools

输出数据样例：

    {
        "redis_up": 1,
        "redis_connected_clients": 1,
        "redis_config_maxmemory": 3972075520,
        "redis_process_id": 14039,
        "redis_aof_enabled": 0,
        "redis_connections_received_total": 37,
        "redis_expired_keys_total": 0,
        "redis_cluster_enabled": 0,
        "redis_connected_slaves": 0,
        "redis_rejected_connections_total": 0,
        "redis_uptime_in_seconds": 230656,
        "redis_evicted_keys_total": 0,
        "redis_memory_used_bytes": 848752,
        "redis_memory_used_peak_bytes": 909264,
        "redis_memory_used_rss_bytes": 4235264,
        "redis_blocked_clients": 0,
        "redis_start_time_seconds": "1632651380",
        "redis_db_keys": 0,
        "redis_config_maxclients": 10000
    }  
