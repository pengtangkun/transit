## elasticsearch

一 采集指标

| 指标说明 | 指标参数     |
|--------| -------------|
| 1 accounting断路器最大内存限制 | elasticsearch_breakers_accounting_limit_size_bytes |
| 2 列数据断路器最大内存限制 | elasticsearch_breakers_fielddata_limit_size_bytes |
| 3 请求中的断路器最大内存限制 | elasticsearch_breakers_in_flight_requests_limit_size_bytes |
| 4 父断路器最大内存限制 | elasticsearch_breakers_parent_limit_size_bytes |
| 5 请求断路器最大内存限制 | elasticsearch_breakers_request_limit_size_bytes |
| 6 集群健康状态 | elasticsearch_cluster_health_status |
| 7 elasticsearch版本信息         | elasticsearch_clusterinfo_version_info |
| 8 块设备可用空间（字节） | elasticsearch_filesystem_data_available_bytes |
| 9 块设备空闲空间（字节） | elasticsearch_filesystem_data_free_bytes |
| 10 块设备总空间（字节） | elasticsearch_filesystem_data_size_bytes |
| 11 节点上的文档数 | elasticsearch_indices_docs |
| 12 节点上删除的文档数 | elasticsearch_indices_docs_deleted |
| 13 累计刷新时间（秒） | elasticsearch_indices_flush_time_seconds |
| 14 总刷新次数 | elasticsearch_indices_flush_total |
| 15 查询miss数 | elasticsearch_indices_query_miss_count |
| 16 查询总耗时 | elasticsearch_indices_search_query_time_seconds |
| 17 查询总次数 | elasticsearch_indices_search_query_total |
| 18 已存储的索引数据大小（字节） | elasticsearch_indices_store_size_bytes |
| 19 JVM缓存池当前用量（字节） | elasticsearch_jvm_buffer_pool_used_bytes |
| 20 JVM老年代GC次数 | elasticsearch_jvm_gc_old_collection_seconds_count |
| 21 JVM年轻代GC次数 | elasticsearch_jvm_gc_young_collection_seconds_count |
| 22 JVM老年代GC用时（秒） | elasticsearch_jvm_gc_old_collection_seconds_sum |
| 23 JVM年轻代GC用时（秒） | elasticsearch_jvm_gc_young_collection_seconds_sum |
| 24 JVM内存最大值（字节） | elasticsearch_jvm_memory_max_bytes |
| 25 节点角色 | elasticsearch_nodes_roles |
| 26 OS CPU占用率 | elasticsearch_os_cpu_percent |
| 27 空闲物理内存字节数 | elasticsearch_os_mem_free_bytes |
| 28 占用物理内存字节数 | elasticsearch_os_mem_used_bytes |
| 29 进程cpu占用率 | elasticsearch_process_cpu_percent |
| 30 进程占用cpu时间 | elasticsearch_process_cpu_time_seconds_sum |
| 31 允许打开的最大文件数 | elasticsearch_process_max_files_descriptors |
| 32 进程打开的文件数 | elasticsearch_process_open_files_count |
| 33 接收的包总数 | elasticsearch_transport_rx_packets_total |
| 34 发送的包总数 | elasticsearch_transport_tx_packets_total |

二 使用方法

python elasticsearch.py --ip ip地址 --port 端口号 

示例

python elasticsearch.py --ip 127.0.0.1 --port 18115
