#!/usr/bin/env python3
# -*- coding:utf8 -*-
# Author: light.wang <youremail@example.com>
# Create Date: 2021-09-28 10:21:17
# Last Modified: 2021-09-28 17:52:17
# Description: 该适配操作系统：centos6、7

import json
import psycopg2
import argparse
import subprocess


class PostgreCollectInfo(object):

    def __init__(self):

        # 检测postgre运行状态,运行时值为1
        postgre_up_status = self.shell_value('ps -ef|grep -o postgre|wc -l').strip()
        self.postgre_up = 0 if int(postgre_up_status) > 2 else 1
        if self.postgre_up == 0:
            self.postgre_pid = self.shell_value("ps -ef |grep postgre|grep -v grep|awk -F ' ' '{print $3}'|tail -1").strip()
        else:
            self.postgre_pid = ''

    # shell标准输出
    @staticmethod
    def shell_value(cmd):
        shell = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        cmd_stdout = bytes.decode(shell.stdout)
        return cmd_stdout

    # 参数定义
    @staticmethod
    def arguments():
        parser = argparse.ArgumentParser()
        parser.add_argument("-ip", "--ip_address", help="IP ADDRESS")
        parser.add_argument("-port", "--port", help="PORT", default=5432)
        parser.add_argument("-user", "--user", help="USER", default='root')
        parser.add_argument("-passwd", "--passwd", help="PASSWD", default='root')
        args = parser.parse_args()
        return args

    # 连接数据库
    def postgre_value(self, sql):
        args = self.arguments()
        conn = psycopg2.connect(host=args.ip_address, user=args.user, password=args.passwd,port=int(args.port),database="postgres")
        cursor = conn.cursor()
        cursor.execute(sql)
        conn.commit()
        return cursor

    # 允许打开的最大文件数
    def process_max_fds(self):
        sql = "show max_files_per_process;"
        process_max_fds_value = self.postgre_value(sql).fetchone()[0] if self.postgre_up == 0 else ''
        return process_max_fds_value

    # 打开的文件数
    def process_open_fds(self):
        tmp = self.shell_value('ls -l /proc/{}/fd |wc -l'.format(self.postgre_pid)).strip()
        process_open_fds_value = tmp if self.postgre_up == 0 else ''
        return process_open_fds_value

    # 占用的内存字节数
    def process_resident_memory_bytes(self):
        tmp = self.shell_value("ps -eo pid,rss|grep %s |awk -F ' ' '{print $2}'|head -1" % self.postgre_pid).strip()
        process_resident_memory_bytes_value = tmp if self.postgre_up == 0 else ''
        return process_resident_memory_bytes_value

    # 服务启动时间戳
    def process_start_time_seconds(self):
        tmp = self.shell_value("ps -o lstart -p {} | tail -n 1".format(self.postgre_pid))
        tmp_value = self.shell_value("date -d \"{}\" +%s".format(tmp)).strip()
        process_start_time_seconds_value = tmp_value if self.postgre_up == 0 else ''
        return process_start_time_seconds_value

    # 进程占用cpu总时间（秒）
    def process_cpu_seconds_total(self):
        tmp = self.shell_value("ps -eo pid,etimes|grep %s|awk -F ' ' '{print $2}'|head -1" % self.postgre_pid).strip()
        process_cpu_seconds_total_value = tmp if self.postgre_up == 0 else ''
        return process_cpu_seconds_total_value

    def run(self):

        collect_info = {
            "pg_up": self.postgre_up,
            "process_max_fds": self.process_max_fds(),
            "process_open_fds": self.process_open_fds(),
            "process_resident_memory_bytes": self.process_resident_memory_bytes(),
            "process_cpu_seconds_total": self.process_cpu_seconds_total(),
            "process_start_time_seconds":self.process_start_time_seconds()
        }

        print(json.dumps(collect_info))
        return json.dumps(collect_info)


if __name__ == '__main__':
    postgre = PostgreCollectInfo()
    postgre.run()

    # 示例
    # python3 postgresql.py --ip 10.0.9.151 --port 18126 --user synthetic_user --passwd "A0gqdr7c(Lfsuid"

