## PostgreSql

一 采集指标

| 指标说明 | 指标参数     |
|--------| -------------|
| 1 最后一次扫描是否连接到服务，0为yes，1为no | pg_up |
| 2 进程占用cpu总时间（秒）   |  process_cpu_seconds_total |
| 3 允许打开的最大文件数    | process_max_fds  |
| 4 打开的文件数   | process_open_fds  |
| 5 占用的内存字节数    | process_resident_memory_bytes  |
| 6 启动时间戳（秒）    | process_start_time_seconds  |

二 使用方法

python postgresql.py --ip ip地址 --port 端口号 --user 用户名 --passwd 密码

示例

python3 postgresql.py --ip 10.0.9.151 --port 18126 --user synthetic_user --passwd "A0gqdr7c(Lfsuid"

三 使用的三方库

psycopg2

psycopg2-binary
